Move the nixpkgs-nixerl files onto this directory
